<?php

const SERVER_IP = '192.168.200.7';
define('CAPTURES_PATH', 'captures/');
define('CAMERAS_CONFIG_FILE', 'cameras.json');

function get_cameras_with_stream_urls() {
    if (!file_exists(CAMERAS_CONFIG_FILE)) {
        return [];
    }
    $cameras = json_decode(file_get_contents(CAMERAS_CONFIG_FILE), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return [];
    }

    $cameras_with_urls = [];
    foreach ($cameras as $camera) {
        $camera_id = $camera['id'] ?? preg_replace('/[^a-zA-Z0-9_-]/', '', $camera['name']);
        
        $stream_url = "http://" . SERVER_IP . ":8080/streams/" . $camera_id . "/index.m3u8";

        $cameras_with_urls[] = [
            "id" => $camera_id,
            "name" => $camera['name'],
            "rtsp_url" => $camera['rtsp_url'], 
            "streamType" => "hls",
            "streamUrl" => $stream_url, 
            "ptz" => $camera['ptz'] ?? false
        ];
    }
    return $cameras_with_urls;
}