<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Acceso no autorizado']);
    exit;
}

require_once 'config.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'getCameras':
        echo json_encode(['success' => true, 'cameras' => get_cameras_with_stream_urls()]);
        break;

    case 'addCamera':
        $data = json_decode(file_get_contents('php://input'), true);
        $name = trim($data['name'] ?? '');
        $rtsp = trim($data['rtsp_url'] ?? '');

        if (empty($name) || empty($rtsp)) {
            echo json_encode(['success' => false, 'message' => 'Nombre y URL RTSP son requeridos.']);
            exit;
        }

        $cameras = file_exists(CAMERAS_CONFIG_FILE) ? json_decode(file_get_contents(CAMERAS_CONFIG_FILE), true) : [];

        foreach ($cameras as $camera) {
            if (strcasecmp($camera['name'], $name) == 0) {
                echo json_encode(['success' => false, 'message' => 'Ya existe una cámara con ese nombre.']);
                exit;
            }
        }

        $new_camera = [
            'id' => 'cam' . uniqid(),
            'name' => $name,
            'rtsp_url' => $rtsp,
            'ptz' => true 
        ];
        $cameras[] = $new_camera;

        if (file_put_contents(CAMERAS_CONFIG_FILE, json_encode($cameras, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES))) {
            $message = 'Cámara agregada con éxito.';
            echo json_encode(['success' => true, 'message' => $message]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error al guardar la cámara.']);
        }
        break;

    case 'deleteCamera':
         $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['id'] ?? '';

        if (empty($id)) {
            echo json_encode(['success' => false, 'message' => 'ID de cámara no especificado.']);
            exit;
        }

        $cameras = json_decode(file_get_contents(CAMERAS_CONFIG_FILE), true);
        $cameras_filtered = array_filter($cameras, function($cam) use ($id) {
            return $cam['id'] !== $id;
        });

        if (count($cameras) === count($cameras_filtered)) {
             echo json_encode(['success' => false, 'message' => 'Cámara no encontrada.']);
             exit;
        }
        
        if (file_put_contents(CAMERAS_CONFIG_FILE, json_encode(array_values($cameras_filtered), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES))) {
            echo json_encode(['success' => true, 'message' => 'Cámara eliminada con éxito.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error al eliminar la cámara.']);
        }
        break;

   case 'ptzControl':
    $input = json_decode(file_get_contents('php://input'), true);
    $cameraId = $input['cameraId'] ?? null;
    $ptzAction = $input['ptzAction'] ?? null;
    $preset = $input['preset'] ?? null;

    if (!$cameraId || (!$ptzAction && !$preset)) {
        echo json_encode(['success' => false, 'message' => 'Faltan datos de c�mara o acci�n/preset']);
        exit;
    }

    // Buscar c�mara en la lista
    $all_cameras = get_cameras_with_stream_urls(); 
    $target_camera = null;
    foreach ($all_cameras as $camera) {
        if ($camera['id'] === $cameraId) {
            $target_camera = $camera;
            break;
        }
    }

    if (!$target_camera) {
        echo json_encode(['success' => false, 'message' => 'C�mara no encontrada.']);
        exit;
    }


    $rtsp_url = $target_camera['rtsp_url'];
    $pattern = "/rtsp:\\/\\/(?:(?P<user>[^:]+):(?P<pass>[^@]+)@)?(?P<ip>[^\\/:]+)/";
    if (!preg_match($pattern, $rtsp_url, $matches)) {
        echo json_encode(['success' => false, 'message' => 'No se pudo extraer la IP de la URL RTSP.']);
        exit;
    }

    $ip = $matches['ip'];
    $user = $matches['user'] ?? 'admin';
    $password = $matches['pass'] ?? '123';


    $payload = [
        'ip' => $ip,
        'user' => $user,
        'password' => $password,
    ];

    if ($preset) {
        $payload['preset'] = $preset;
    } else {
        $payload['action'] = $ptzAction;
    }


    $ptz_service_url = 'http://127.0.0.1:5000/ptz'; 
    $ch = curl_init($ptz_service_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        echo json_encode(['success' => false, 'message' => 'Error al contactar el servicio PTZ', 'details' => $error]);
    } else {
        echo $response; // Flask devuelve el JSON final
    }
    break;

    case 'saveCapture':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método no permitido']);
            exit;
        }
        $data = json_decode(file_get_contents('php://input'), true);
        $imageData = $data['imageDataUrl'] ?? '';
        $cameraName = $data['cameraName'] ?? 'desconocida';

        if (empty($imageData)) {
            echo json_encode(['success' => false, 'message' => 'No se recibieron datos de imagen.']);
            exit;
        }
        $safeCameraName = preg_replace('/[^a-zA-Z0-9_-]/', '', $cameraName);
        $filename = 'capture_' . $safeCameraName . '_' . date('Ymd_His') . '.jpg';
        $filePath = CAPTURES_PATH . $filename;
        $imageData = str_replace('data:image/jpeg;base64,', '', $imageData);
        $imageData = str_replace(' ', '+', $imageData);
        $decodedImage = base64_decode($imageData);

        if (file_put_contents($filePath, $decodedImage)) {
            echo json_encode(['success' => true, 'message' => 'Captura guardada en el servidor.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error al guardar la captura en el servidor.']);
        }
        break;

    case 'getCaptures':
        $files = glob(CAPTURES_PATH . '*.jpg');
        $captures = [];
        if ($files) {
            usort($files, function($a, $b) {
                return filemtime($b) - filemtime($a);
            });
            foreach($files as $file) {
                $captures[] = [
                    'url' => $file,
                    'name' => basename($file),
                    'timestamp' => filemtime($file)
                ];
            }
        }
        echo json_encode(['success' => true, 'captures' => $captures]);
        break;

    case 'deleteCapture':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método no permitido']);
            exit;
        }
        $data = json_decode(file_get_contents('php://input'), true);
        $filenames = $data['filenames'] ?? [];

        if (empty($filenames) || !is_array($filenames)) {
            echo json_encode(['success' => false, 'message' => 'No se especificaron archivos.']);
            exit;
        }

        $deleted_count = 0;
        $error_count = 0;

        foreach ($filenames as $filename) {
            $safe_filename = basename($filename);
            $filePath = CAPTURES_PATH . $safe_filename;

            if (file_exists($filePath)) {
                if (unlink($filePath)) {
                    $deleted_count++;
                } else {
                    $error_count++;
                }
            } else {
                $error_count++;
            }
        }

        if ($deleted_count > 0) {
            echo json_encode(['success' => true, 'message' => "$deleted_count capturas eliminadas."]);
        } else {
            echo json_encode(['success' => false, 'message' => 'No se pudo eliminar ninguna captura.']);
        }
        break;

    case 'changePassword':
        $credentialsFile = __DIR__ . '/credentials.json';
        $input = json_decode(file_get_contents('php://input'), true);
        $currentPassword = $input['currentPassword'] ?? '';
        $newPassword = $input['newPassword'] ?? '';

        if (empty($currentPassword) || empty($newPassword)) {
            echo json_encode(['success' => false, 'message' => 'Debes completar todos los campos.']);
            exit;
        }

        if (strlen($newPassword) < 2) {
            echo json_encode(['success' => false, 'message' => 'La nueva contraseña debe tener al menos 2 caracteres.']);
            exit;
        }

        $credentials = json_decode(file_get_contents($credentialsFile), true);

        if ($currentPassword !== $credentials['password']) {
            echo json_encode(['success' => false, 'message' => 'La contraseña actual es incorrecta.']);
            exit;
        }

        $credentials['password'] = $newPassword;

        if (file_put_contents($credentialsFile, json_encode($credentials, JSON_PRETTY_PRINT))) {
            echo json_encode(['success' => true, 'message' => '¡Contraseña actualizada con éxito!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error: No se pudo guardar la nueva contraseña.']);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Acción no válida']);
        break;
}