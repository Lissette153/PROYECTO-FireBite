let cameras = [];
let currentSingleViewIndex = -1;
let notificationTimeout;
let selectedCaptures = new Set();

function showNotification(message, type = 'info') {
    const notificationContainer = document.getElementById('notification-container');
    if (!notificationContainer) return;

    clearTimeout(notificationTimeout);

    const notif = document.createElement('div');
    notif.className = `notification ${type}`;
    notif.textContent = message;

    notificationContainer.innerHTML = '';
    notificationContainer.appendChild(notif);

    notif.classList.add('show');

    notificationTimeout = setTimeout(() => {
        notif.classList.remove('show');
        if (notif.parentNode) {
            notif.parentNode.removeChild(notif);
        }
    }, 4000);
}

async function fetchFromAPI(action, options = {}) {
    try {
        const response = await fetch(`api.php?action=${action}`, options);
        if (!response.ok) throw new Error(`Error de red: ${response.statusText}`);
        return await response.json();
    } catch (error) {
        console.error(`Error en API action '${action}':`, error);
        showNotification('Error de conexión con el servidor.', 'error');
        return { success: false, message: error.message };
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const cameraGridContainer = document.getElementById('cameraGridContainer');
    const capturesGridContainer = document.getElementById('capturesGridContainer');
    const navLinks = document.querySelectorAll('#sidebar .nav-link');
    const views = document.querySelectorAll('.view-section');
    const changePasswordForm = document.getElementById('changePasswordForm');
    const singleCameraView = document.getElementById('single-camera-view');
    const singleCameraName = document.getElementById('single-camera-name');
    const singleCameraFeed = document.getElementById('single-camera-feed');
    const backToGridBtn = document.getElementById('back-to-grid-btn');
    const ptzSidebar = document.getElementById('ptz-controls-sidebar');
    const quickCaptureBtnSingle = document.getElementById('quick-capture-btn-single');
    const addCameraForm = document.getElementById('addCameraForm');
    const cameraListContainer = document.getElementById('cameraList');
    const deleteSelectedCapturesBtn = document.getElementById('deleteSelectedCaptures');
    const downloadSelectedCapturesBtn = document.getElementById('downloadSelectedCaptures');
    const selectAllCapturesCheckbox = document.getElementById('selectAllCapturesCheckbox');
    const dashboardWrapper = document.getElementById('dashboard-wrapper');
    const menuBtn = document.getElementById('menuBtn');
    const closeSidebarBtn = document.getElementById('closeSidebar');
    const sidebar = document.getElementById('sidebar');

    const confirmationModal = document.getElementById('confirmation-modal');
    const confirmBtn = document.getElementById('confirm-password-change');
    const cancelBtn = document.getElementById('cancel-password-change');

    function init() {
        setupEventListeners();
	switchView('cameras');
    }

    function setupEventListeners() {
        navLinks.forEach(link => link.addEventListener('click', (e) => {
            e.preventDefault();
            const viewId = e.currentTarget.getAttribute('data-view');
            switchView(viewId, e.currentTarget);
        }));

        if (menuBtn) menuBtn.addEventListener('click', () => sidebar.classList.add('active'));
        if (closeSidebarBtn) closeSidebarBtn.addEventListener('click', () => sidebar.classList.remove('active'));

        if (addCameraForm) addCameraForm.addEventListener('submit', handleAddCamera);
        if (deleteSelectedCapturesBtn) deleteSelectedCapturesBtn.addEventListener('click', handleDeleteSelectedCaptures);
        if (downloadSelectedCapturesBtn) downloadSelectedCapturesBtn.addEventListener('click', handleDownloadSelectedCaptures);
        if (selectAllCapturesCheckbox) selectAllCapturesCheckbox.addEventListener('change', handleSelectAllCaptures);
        if (backToGridBtn) backToGridBtn.addEventListener('click', hideSingleView);
        if (ptzSidebar) ptzSidebar.addEventListener('click', handlePtzClick);
        if (quickCaptureBtnSingle) quickCaptureBtnSingle.addEventListener('click', takeSingleViewCapture);
        if (singleCameraFeed) singleCameraFeed.addEventListener('dblclick', toggleFullscreen);

        // --- Modal de Cambiar Contraseña ---
        if (changePasswordForm) {
            changePasswordForm.addEventListener('submit', function(e) {
                e.preventDefault(); // detener envío automático
                confirmationModal.style.display = 'flex'; // mostrar modal centrado
            });
        }

        if (closeModal) {
            closeModal.addEventListener("click", () => {
                confirmationModal.style.display = "none";
            });
        }
        if (cancelBtn) {
            cancelBtn.addEventListener("click", () => {
                confirmationModal.style.display = "none";
            });
        }

        if (confirmBtn) {
            confirmBtn.addEventListener("click", async () => {
                confirmationModal.style.display = "none";

                const currentPassword = document.getElementById('currentPassword').value;
                const newPassword = document.getElementById('newPassword').value;
                const confirmNewPassword = document.getElementById('confirmNewPassword').value;

                if (newPassword !== confirmNewPassword) {
                    showNotification('Las nuevas contraseñas no coinciden.', 'error');
                    return;
                }

                try {
                    const res = await fetch('api.php?action=changePassword', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ currentPassword, newPassword })
                    });
                    const data = await res.json();
                    showNotification(data.message, data.success ? 'success' : 'error');

                    if (data.success) changePasswordForm.reset(); // limpiar formulario
                } catch (err) {
                    console.error(err);
                    showNotification('Error al cambiar la contraseña.', 'error');
                }
            });
        }
    }
 

  
    async function switchView(viewId, clickedLink = null) {
        if (!clickedLink) {
            clickedLink = document.querySelector(`#sidebar a[data-view="${viewId}"]`);
        }

        navLinks.forEach(l => l.classList.remove('active'));
        if (clickedLink) clickedLink.classList.add('active');

        views.forEach(section => {
            section.classList.remove('active-view');
            section.style.display = 'none';
        });

        const activeView = document.getElementById(`${viewId}-view`);
        if (activeView) {
            activeView.style.display = 'block';
            activeView.classList.add('active-view');
        }

        if (viewId === 'captures') {
            await renderCaptures();
        }
        if (viewId === 'cameras') {
            await displayCamerasInGrid();
        }
        if (viewId === 'camera-settings') {
            await displayCameraSettings();
        }
    }

    function setupHlsPlayer(videoElement, streamUrl, videoContainer) {
        if (Hls.isSupported()) {
            const hls = new Hls({
                maxBufferLength: 30,
                maxMaxBufferLength: 60,
                liveSyncDurationCount: 3,
                liveMaxLatencyDurationCount: 5,
            });
            hls.loadSource(streamUrl);
            hls.attachMedia(videoElement);
            hls.on(Hls.Events.ERROR, function(event, data) {
                if (data.fatal) {
                    console.error(`Error de HLS irrecuperable para ${streamUrl}: ${data.details}`);
                    hls.destroy();
                    if (videoContainer) {
                        videoContainer.innerHTML = '<div class="no-signal-overlay"><p>Sin Señal</p></div>';
                    }
                }
            });
        } else if (videoElement.canPlayType('application/vnd.apple.mpegurl')) {
            videoElement.src = streamUrl;
            videoElement.addEventListener('error', () => {
                if (videoContainer) {
                    videoContainer.innerHTML = '<div class="no-signal-overlay"><p>Sin Señal</p></div>';
                }
            });
        }
    }

    async function displayCamerasInGrid() {
        if (!cameraGridContainer) return;
        cameraGridContainer.innerHTML = '<p>Cargando cámaras...</p>';
        const cameraData = await fetchFromAPI('getCameras');

        if (cameraData && cameraData.cameras) {
            cameras = cameraData.cameras;
        } else {
            cameras = [];
        }

        cameraGridContainer.innerHTML = '';
        if (cameras.length === 0) {
            cameraGridContainer.innerHTML = '<p class="no-cameras-message">No hay cámaras configuradas.</p>';
            return;
        }

        cameras.forEach((camera, index) => {
            const cameraFeedDiv = document.createElement('div');
            cameraFeedDiv.className = 'camera-feed';
            const videoContainer = document.createElement('div');
            videoContainer.className = 'camera-placeholder';
            const videoElement = document.createElement('video');
            videoElement.className = 'camera-video-element';
            videoElement.muted = true;
            videoElement.autoplay = true;
            videoElement.setAttribute('playsinline', '');
            videoElement.crossOrigin = "anonymous";
            setupHlsPlayer(videoElement, camera.streamUrl, videoContainer);
            videoContainer.appendChild(videoElement);

            const captureBtn = document.createElement('button');
            captureBtn.className = 'quick-capture-grid-btn';
            captureBtn.innerHTML = '<i class="fas fa-camera"></i>';
            captureBtn.title = 'Tomar captura';
            captureBtn.addEventListener('click', (event) => {
                event.stopPropagation();
                takeAndSaveCapture(camera.name, videoElement);
            });

            videoContainer.appendChild(captureBtn);

            const infoDiv = document.createElement('div');
            infoDiv.className = 'camera-info';
            infoDiv.textContent = camera.name;
            cameraFeedDiv.appendChild(videoContainer);
            cameraFeedDiv.appendChild(infoDiv);
            cameraGridContainer.appendChild(cameraFeedDiv);

            videoContainer.addEventListener('click', () => showSingleView(index));
        });
    }

    function showSingleView(index) {
        if (index < 0 || index >= cameras.length) return;

        currentSingleViewIndex = index;
        const camera = cameras[index];
        singleCameraName.textContent = camera.name;
        singleCameraFeed.innerHTML = '';
        const videoElement = document.createElement('video');
        videoElement.autoplay = true;
        videoElement.controls = true;
        videoElement.setAttribute('playsinline', '');
        videoElement.crossOrigin = "anonymous";

        setupHlsPlayer(videoElement, camera.streamUrl, singleCameraFeed);
        singleCameraFeed.appendChild(videoElement);

        ptzSidebar.style.display = camera.ptz ? 'flex' : 'none';

        // OCULTAR TODO LO DEMÁS
        dashboardWrapper.style.display = 'none';
        capturesGridContainer?.parentElement && (capturesGridContainer.parentElement.style.display = 'none');
        singleCameraView.style.display = 'flex';
        singleCameraView.classList.add('fade-in');
    }

    function hideSingleView() {
        singleCameraView.style.display = 'none';
        dashboardWrapper.style.display = 'flex';
        singleCameraFeed.innerHTML = '';
    }

    function toggleFullscreen(event) {
        const element = event.currentTarget;
        if (!document.fullscreenElement) {
            element.requestFullscreen().catch(err => {
                alert(`Error al intentar entrar en pantalla completa: ${err.message} (${err.name})`);
            });
        } else {
            document.exitFullscreen();
        }
    }

    async function handlePtzClick(event) {
        const target = event.target.closest('button[data-ptz]');
        if (!target) return;
        const ptzAction = target.dataset.ptz;
        const camera = cameras[currentSingleViewIndex];
        const response = await fetchFromAPI('ptzControl', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cameraId: camera.id, ptzAction: ptzAction })
        });
        if (response && response.success) {
            showNotification(response.message, 'info');
        } else if (response) {
            showNotification(response.message, 'error');
        }
    }

    function takeSingleViewCapture() {
        const camera = cameras[currentSingleViewIndex];
        const videoElement = singleCameraFeed.querySelector('video');
        if (camera && videoElement) {
            takeAndSaveCapture(camera.name, videoElement);
        }
    }

    async function renderCaptures() {
        if (!capturesGridContainer) return;
        capturesGridContainer.innerHTML = '<div class="loader">Cargando...</div>';
        const data = await fetchFromAPI('getCaptures');

        if(selectAllCapturesCheckbox) selectAllCapturesCheckbox.checked = false;

        if (!data || !data.captures) {
            capturesGridContainer.innerHTML = '<div class="empty-state-message">No se pudieron cargar las capturas.</div>';
            return;
        }
        if (data.captures.length === 0) {
            capturesGridContainer.innerHTML = '<div class="empty-state-message">No se ha guardado ninguna captura.</div>';
            return;
        }
        capturesGridContainer.innerHTML = '';
        selectedCaptures.clear();
        updateCaptureActionButtons();

        const totalCaptures = data.captures.length;

        data.captures.forEach(capture => {
            const captureBox = document.createElement('div');
            captureBox.className = 'capture-box';
            captureBox.dataset.filename = capture.name;

            const imgElement = document.createElement('img');
            imgElement.src = `${capture.url}?t=${new Date().getTime()}`;
            imgElement.alt = `Captura: ${capture.name}`;
            imgElement.loading = 'lazy';
            captureBox.appendChild(imgElement);

            const captureInfo = document.createElement('div');
            captureInfo.className = 'capture-info';
            captureInfo.innerHTML = `<p>${capture.name}</p><span>${new Date(capture.timestamp * 1000).toLocaleString('es-CL')}</span>`;
            captureBox.appendChild(captureInfo);

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.className = 'capture-checkbox';
            checkbox.addEventListener('change', () => {
                if (checkbox.checked) {
                    selectedCaptures.add(capture.name);
                } else {
                    selectedCaptures.delete(capture.name);
                }
                updateCaptureActionButtons();
                if(selectAllCapturesCheckbox) selectAllCapturesCheckbox.checked = (selectedCaptures.size > 0 && selectedCaptures.size === totalCaptures);
            });
            captureBox.appendChild(checkbox);

            const downloadBtn = document.createElement('button');
            downloadBtn.className = 'capture-download-btn';
            downloadBtn.innerHTML = 'D';
            downloadBtn.title = 'Descargar captura';
            downloadBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const link = document.createElement('a');
                link.href = capture.url;
                link.download = capture.name;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            });
            captureBox.appendChild(downloadBtn);

            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'capture-delete-btn';
            deleteBtn.innerHTML = 'X';
            deleteBtn.title = 'Eliminar captura';
            deleteBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                if (confirm(`¿Seguro que quieres eliminar ${capture.name}?`)) {
                    await deleteCaptures([capture.name]);
                }
            });
            captureBox.appendChild(deleteBtn);

            capturesGridContainer.appendChild(captureBox);
        });
    }

    function handleSelectAllCaptures(event) {
        const isChecked = event.target.checked;
        const allCheckboxes = document.querySelectorAll('.capture-checkbox');
        
        allCheckboxes.forEach(checkbox => {
            checkbox.checked = isChecked;
            const filename = checkbox.closest('.capture-box').dataset.filename;
            if(isChecked) selectedCaptures.add(filename);
            else selectedCaptures.delete(filename);
        });

        updateCaptureActionButtons();
    }

    function updateCaptureActionButtons() {
        const hasSelection = selectedCaptures.size > 0;
        if(deleteSelectedCapturesBtn) deleteSelectedCapturesBtn.style.display = hasSelection ? 'inline-block' : 'none';
        if(downloadSelectedCapturesBtn) downloadSelectedCapturesBtn.style.display = hasSelection ? 'inline-block' : 'none';
    }

    async function deleteCaptures(filenames) {
        const response = await fetchFromAPI('deleteCapture', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filenames: filenames })
        });
        if(response && response.success){
            showNotification(response.message, 'success');
            await renderCaptures();
        } else {
            showNotification(response.message || 'Error al eliminar capturas', 'error');
        }
    }

    async function handleDeleteSelectedCaptures() {
        if (selectedCaptures.size === 0) return;
        if (confirm(`¿Seguro que quieres eliminar ${selectedCaptures.size} capturas seleccionadas?`)) {
            await deleteCaptures(Array.from(selectedCaptures));
        }
    }

    function handleDownloadSelectedCaptures() {
        if (selectedCaptures.size === 0) return;
        selectedCaptures.forEach(filename => {
            const link = document.createElement('a');
            link.href = `captures/${filename}`;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });
    }

    async function takeAndSaveCapture(cameraName, videoElement) {
        if (!videoElement) return;
        const canvas = document.createElement('canvas');
        canvas.width = videoElement.videoWidth;
        canvas.height = videoElement.videoHeight;
        if (canvas.width === 0 || canvas.height === 0) {
            showNotification('Error: El video no tiene dimensiones para capturar.', 'error');
            return;
        }
        const ctx = canvas.getContext('2d');
        ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
        const imageDataUrl = canvas.toDataURL('image/jpeg');

        showNotification(`Guardando captura de "${cameraName}"...`);
        const response = await fetchFromAPI('saveCapture', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cameraName, imageDataUrl })
        });

        if (response && response.success) {
            showNotification(`¡Captura de "${cameraName}" guardada!`, 'success');
        } else {
            showNotification(response.message || 'Error al guardar la captura.', 'error');
        }
    }

    async function handleAddCamera(event) {
        event.preventDefault();
        const name = document.getElementById('cameraName').value;
        const rtsp_url = document.getElementById('cameraRtspUrl').value;
        
        if(!name || !rtsp_url) {
            showNotification('Por favor, complete todos los campos de la cámara.', 'error');
            return;
        }

        showNotification('Agregando cámara...', 'info');

        const result = await fetchFromAPI('addCamera', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ name, rtsp_url })
        });
        
        if (result && result.success) {
            showNotification(result.message, 'success');
            addCameraForm.reset();
            await displayCameraSettings();
        } else {
            showNotification(result.message || 'Error al agregar la cámara.', 'error');
        }
    }


   
    
    async function displayCameraSettings() {
        if (!cameraListContainer) return;
        cameraListContainer.innerHTML = '<div class="loader">Cargando...</div>';
        const data = await fetchFromAPI('getCameras');
        
        if(!data || !data.cameras) {
            cameraListContainer.innerHTML = '<div class="empty-state-message">No se pudieron cargar las cámaras.</div>';
            return;
        }

        cameraListContainer.innerHTML = '';
        if(data.cameras.length === 0) {
            cameraListContainer.innerHTML = '<div class="empty-state-message">No hay cámaras configuradas.</div>';
            return;
        }
        
        data.cameras.forEach(camera => {
            const item = document.createElement('div');
            item.className = 'camera-list-item';
            
            const infoDiv = document.createElement('div');
            infoDiv.className = 'camera-item-info';
            infoDiv.innerHTML = `<strong>${camera.name}</strong><br><span>${camera.rtsp_url}</span>`;

            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'delete-camera-btn';
            deleteBtn.dataset.id = camera.id;
            deleteBtn.title = 'Eliminar cámara';
            deleteBtn.innerHTML = 'X';

            item.appendChild(infoDiv);
            item.appendChild(deleteBtn);
            cameraListContainer.appendChild(item);
        });

        document.querySelectorAll('.delete-camera-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                const camId = e.currentTarget.dataset.id;
                const camName = e.currentTarget.parentElement.querySelector('strong').textContent;
                if(confirm(`¿Seguro que quieres eliminar la cámara "${camName}"?`)){
                    const result = await fetchFromAPI('deleteCamera', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({ id: camId })
                    });

                    if (result && result.success) {
                        showNotification(result.message, 'success');
                        await displayCameraSettings();
                    } else {
                        showNotification(result.message || 'Error al eliminar la cámara', 'error');
                    }
                }
            });
        });
    }

    init();
});
