<?php
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header('Location: dashboard.php');
    exit;
}

$error_message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $credentialsFile = 'credentials.json';
    $credentials = null;

    if (file_exists($credentialsFile)) {
        $credentials = json_decode(file_get_contents($credentialsFile), true);
    }

    if (!$credentials || !isset($credentials['users'])) {
        $error_message = 'Error crítico: No se pudo leer la configuración de usuarios.';
    } else {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';

        $found = false;
	
	// Busca las credenciales en usuarios  
        foreach ($credentials['users'] as $user) {
            if ($user['username'] === $username) {
                //  Verificar contraseña encriptada
                if (password_verify($password, $user['password'])) {
                    $_SESSION['loggedin'] = true;
                    $_SESSION['username'] = $username;
                    $_SESSION['role'] = $user['role']; // Guardar rol 
                    header('Location: dashboard.php');
                    exit;
                } else {
                    $error_message = 'Contraseña incorrecta.';
                }
                $found = true;
                break;
            }
        }

        if (!$found) {
            $error_message = 'Usuario no encontrado.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar SesiÃ³n - FireBITE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styleL.css">
</head>
<body>
    <?php if (!empty($error_message)): ?>
        <div class="error-message"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <div class="login-container">
        <div class="login-left">
            <img src="img/profile.png" class="profile-img" alt="Perfil">
            <h2>Bienvenido</h2>
            <h5>Inicie sesiÃ³n en su cuenta</h5>
            <form action="index.php" method="POST">
                <div class="input-group mb-3">
                    <span class="input-group-text"><img src="img/usuario_log.png" class="icon-input" alt=""></span>
                    <input type="text" id="username" name="username" class="form-control" placeholder="Usuario" required>
                </div>
                <div class="input-group mb-4">
                    <span class="input-group-text"><img src="img/hola.png" class="icon-input" alt=""></span>
                    <input type="password" id="password" name="password" class="form-control" placeholder="ContraseÃ±a" required>
                </div>
                <button type="submit" class="btn btn-login">Ingresar</button>
            </form>
        </div>
        <div class="login-right">
            <img src="img/inicio_s.jpg" class="bg-img" alt="Imagen de fondo">
        </div>    

        <div class="logos-container">
            <img src="img/logo.webp" class="LOGO1"> 
            <img src="img/logo_conaf.webp" class="LOGO2"> 
        </div>
    </div>
</body>
</html>