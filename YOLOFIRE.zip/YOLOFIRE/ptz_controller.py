from flask import Flask, request, jsonify
from requests.auth import HTTPDigestAuth
import requests
import time
import xml.etree.ElementTree as ET
from flask import Flask, request, jsonify
from onvif import ONVIFCamera, exceptions
from time import sleep

app = Flask(__name__)

SOAP_HEADERS = {"Content-Type": "application/soap+xml"}

def soap_post(url, body, user, pwd, timeout=6):
    return requests.post(url, data=body, headers=SOAP_HEADERS,
                         auth=HTTPDigestAuth(user, pwd), timeout=timeout)

def discover_service_urls(ip, user, pwd):
    """Descubre las URLs reales de Media y PTZ v�a GetCapabilities.
       Si falla el parseo, usa rutas est�ndar como fallback."""
    device_url = f"http://{ip}/onvif/device_service"

    body = """
    <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">
      <s:Body>
        <GetCapabilities xmlns="http://www.onvif.org/ver10/device/wsdl">
          <Category>All</Category>
        </GetCapabilities>
      </s:Body>
    </s:Envelope>
    """
    media_url = f"http://{ip}/onvif/Media"
    ptz_url   = f"http://{ip}/onvif/PTZ"

    try:
        r = soap_post(device_url, body, user, pwd)
        r.raise_for_status()
        root = ET.fromstring(r.text)

        # Buscar cualquier XAddr y clasificar por si contiene 'media' o 'ptz'
        for elem in root.iter():
            if elem.tag.endswith('XAddr') and elem.text:
                txt = elem.text.strip()
                low = txt.lower()
                if 'media' in low:
                    media_url = txt
                if 'ptz' in low:
                    ptz_url = txt
    except Exception:
        # Si algo falla, seguimos con defaults
        pass

    return media_url, ptz_url

def get_profile_token(media_url, user, pwd):
    """Obtiene el primer ProfileToken disponible v�a GetProfiles."""
    body = """
    <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">
      <s:Body>
        <GetProfiles xmlns="http://www.onvif.org/ver10/media/wsdl"/>
      </s:Body>
    </s:Envelope>
    """
    r = soap_post(media_url, body, user, pwd)
    if r.status_code != 200:
        raise Exception(f"GetProfiles HTTP {r.status_code}: {r.text}")

    root = ET.fromstring(r.text)

    # Algunos firmwares usan <Profiles token="...">, otros <Profile token="...">
    token = None
    for elem in root.iter():
        if 'token' in elem.attrib:
            token = elem.attrib.get('token')
            if token:
                break
    if not token:
        raise Exception("No se encontr� ning�n ProfileToken en GetProfiles.")
    return token

def ptz_continuous_move(ptz_url, profile_token, user, pwd, x=0, y=0, z=0, duration=0.3):
    move_body = f"""
    <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
                xmlns:tt="http://www.onvif.org/ver10/schema">
      <s:Body>
        <ContinuousMove xmlns="http://www.onvif.org/ver20/ptz/wsdl">
          <ProfileToken>{profile_token}</ProfileToken>
          <Velocity>
            <tt:PanTilt x="{x}" y="{y}"/>
            <tt:Zoom x="{z}"/>
          </Velocity>
        </ContinuousMove>
      </s:Body>
    </s:Envelope>
    """
    r = soap_post(ptz_url, move_body, user, pwd)
    if r.status_code != 200:
        raise Exception(f"ContinuousMove HTTP {r.status_code}: {r.text}")

    time.sleep(duration)

    stop_body = f"""
    <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">
      <s:Body>
        <Stop xmlns="http://www.onvif.org/ver20/ptz/wsdl">
          <ProfileToken>{profile_token}</ProfileToken>
          <PanTilt>true</PanTilt>
          <Zoom>true</Zoom>
        </Stop>
      </s:Body>
    </s:Envelope>
    """
    r2 = soap_post(ptz_url, stop_body, user, pwd)
    if r2.status_code != 200:
        raise Exception(f"Stop HTTP {r2.status_code}: {r2.text}")

def perform_ptz_action(ip, user, pwd, action):
    try:
        # 1) Descubrir endpoints reales
        media_url, ptz_url = discover_service_urls(ip, user, pwd)

        # 2) Obtener token de perfil
        profile_token = get_profile_token(media_url, user, pwd)

        # 3) Mapear acci�n a velocidades
        pan_speed  = 0.5
        tilt_speed = 0.5
        zoom_speed = 0.5

        x = y = z = 0.0
        if action == "up":
            y = tilt_speed
        elif action == "down":
            y = -tilt_speed
        elif action == "left":
            x = -pan_speed
        elif action == "right":
            x = pan_speed
        elif action == "zoom-in":
            z = zoom_speed
        elif action == "zoom-out":
            z = -zoom_speed
        else:
            return False, "Acci�n PTZ no reconocida", {"driver": "soap"}

        # 4) Ejecutar movimiento continuo + stop
        ptz_continuous_move(ptz_url, profile_token, user, pwd, x, y, z, duration=0.3)
        return True, f"Acci�n '{action}' ejecutada.", {"driver": "soap"}

    except Exception as e:
        return False, f"Error SOAP: {e}", {"driver": "soap"}

@app.route("/ptz", methods=["POST"])
def ptz_control():
    data = request.get_json(force=True, silent=True) or {}
    ip = data.get("ip")
    user = data.get("user")
    password = data.get("password")
    action = data.get("action")

    if not all([ip, user, password, action]):
        return jsonify({
            "success": False,
            "message": "Faltan par�metros (ip, user, password, action)",
            "driver": "soap"
        }), 400

    ok, msg, meta = perform_ptz_action(ip, user, password, action)
    return jsonify({"success": ok, "message": msg, **meta})

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"ok": True, "driver": "soap", "version": "v1.2"})

if __name__ == "__main__":
    # Aseg�rate de matar el proceso Flask anterior y arrancar este
    app.run(host="127.0.0.1", port=5000)
