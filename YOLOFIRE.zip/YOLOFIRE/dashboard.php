<?php
session_start();

// Verificar si el usuario está logeado
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('location: index.php');
    exit;
}

$role = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - YoloFire</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>
</head>
<body>

<div id="dashboard-wrapper" class="d-flex">
    <div class="menu-container gap-2">
        <button id="menuBtn" class="btn">
            <img src="img/menu.png" width="30px">
        </button>
    </div>

    <!-- Sidebar -->
    <aside id="sidebar" class="bg-dark">
        <header id="top-bar">
            <div class="logo-container d-flex align-items-center justify-content-between p-4">
                <h3 class="logo">FireBITE</h3>
                <button id="closeSidebar" class="btn btn-outline-light btn-sm">X</button>
            </div>
            <nav class="nav flex-column">
                <a href="#" class="nav-link active" data-view="cameras">CÃ¡maras
                    <img class="p-2" src="img/camera.png" width="50px">
                </a>
                <a href="#" class="nav-link" data-view="captures">Capturas
                    <img class="p-2" src="img/capture.png" width="54px" height="54px">
                </a>
		<a href="#" class="nav-link" data-view="user-settings">GestiÃ³n de Usuarios
                    <img class="p-2" src="img/user_sett.png" width="54px" height="54px">
                </a>
                <?php if ($role === 'admin'): ?>
                <a href="#" class="nav-link" data-view="camera-settings">GestiÃ³n de CÃ¡maras
                    <img class="p-2" src="img/camera2.png" width="54px" height="54px">
                </a>
		<a href="#" class="nav-link mb-5" data-view="settings">ConfiguraciÃ³n
                    <img class="p-2" src="img/settings.png" width="54px" height="54px">
                </a>
                <?php endif; ?>
            </nav>
            <div class="final">
                <hr class="m-2" width="230px">
                <a href="logout.php" class="btn btn-outline-danger btn-lg m-4 p-4 mt-3">Cerrar sesiÃ³n</a>
            </div>
        </header>
    </aside>

    <!-- Contenedor principal -->
    <main id="main-container" class="flex-grow-1">

        <!-- Vista Cámaras -->
        <div id="cameras-view" class="view-section active-view p-3">
            <header class="main-header mb-3 d-flex align-items-center">
                <h1 class="titulo flex-grow-1 text-center">CÃ¡maras en vivo</h1>
            </header>
            <section class="camera-grid" id="cameraGridContainer"></section>
        </div>

        <!-- Vista Capturas -->
        <div id="captures-view" class="view-section" style="display: none;">
            <header class="main-header mb-3">
                <h1 class="text-center">Captura de CÃ¡maras</h1>
            </header>
            <div class="select-all-container">
                <input type="checkbox" id="selectAllCapturesCheckbox">
                <label for="selectAllCapturesCheckbox">Seleccionar Todo</label>
            </div>
            <hr>
            <div class="capture-actions">
                <button id="deleteSelectedCaptures" class="btn btn-outline-danger">Eliminar</button>
                <button id="downloadSelectedCaptures" class="btn btn-outline-light">Descargar</button>
            </div>
            <hr>
            <section class="capture-grid" id="capturesGridContainer"></section>
        </div>

        <!-- Vista Gestión de Cámaras -->
        <?php if ($role === 'admin'): ?>
        <div id="camera-settings-view" class="view-section" style="display: none;">
            <header class="main-header">
                <h1>GestiÃ³n de CÃ¡maras</h1>
            </header>
            <div class="camera-config-layout d-flex gap-3">

                <div class="settings-form-container">
                    <h2>Agregar CÃ¡maras</h2>
                    <form id="addCameraForm">
                        <div class="input-group p-2">
                            <label for="cameraName">Nombre</label>
                            <input type="text" id="cameraName" placeholder="Nombre de cÃ¡mara" required>
                        </div>
                        <div class="input-group p-2 mt-3 mb-2">
                            <label for="cameraRtspUrl">URL (RTSP)</label>
                            <input type="text" id="cameraRtspUrl" placeholder="rtsp://usuario:pass@ip:port/stream" required>
                        </div>
                        <button type="submit" class="form-button mt-3">Añadir CÃ¡mara</button>
                    </form>
                </div>

                <!-- Lista de Cámaras -->
                <div class="camera-list-container">
                    <h2>CÃ¡maras Agregadas</h2>
                    <div id="cameraList" class="camera-list"></div>
                </div>

            </div>
        </div>

	<!-- Vista Gestión de Usuarios -->
<div id="user-settings-view" class="view-section" style="display: none;">
    <header class="main-header">
        <h1>GestiÃ³n de Usuarios</h1>
    </header>
    <div class="camera-config-layout d-flex gap-3">

        <!-- Solo admins pueden agregar usuarios -->
        <?php if ($role === 'admin'): ?>
        <div class="settings-form-container">
            <h2>Agregar Usuarios</h2>
            <form id="addUser">
                <div class="input-group p-2">
                    <label for="username">Nombre de usuario</label>
                    <input type="text" id="username" placeholder="juan" required>
                </div>
                <div class="input-group p-2 mt-3 mb-2">
                    <label for="password">Contraseña</label>
                    <input type="password" id="password" placeholder="******" required>
                </div>
                <div class="input-group p-2 mt-3 mb-2">
                    <label for="role">Rol</label>
                    <input type="text" id="role" placeholder="admin" required>
                </div>
                <button type="submit" class="form-button mt-3">Agregar Usuario</button>
            </form>
        </div>
        <?php endif; ?>

        <!-- Todos pueden ver la lista de usuarios -->
        <div class="camera-list-container">
            <h2>Listado de usuarios agregados</h2>
            <div id="userList" class="user-list"></div>
        </div>

    </div>
</div>
 
        <!-- Vista Configuración -->
        <div id="settings-view" class="view-section" style="display: none;">
            <header class="main-header">
                <h1 class="text-center">ConfiguraciÃ³n</h1>
            </header>
            <div class="settings-form-container settings-card">
                <h2>Cambiar ContraseÃ±a</h2>
                <form id="changePasswordForm">
                    <div class="input-group">
                        <label for="currentPassword">ContraseÃ±a Actual</label>
                        <input type="password" id="currentPassword" required>
                    </div>
                    <div class="input-group">
                        <label for="newPassword">Nueva ContraseÃ±a</label>
                        <input type="password" id="newPassword" required>
                    </div>
                    <div class="input-group">
                        <label for="confirmNewPassword">Confirmar Nueva ContraseÃ±a</label>
                        <input type="password" id="confirmNewPassword" required>
                    </div>
                    <button type="submit" class="form-button">Cambiar ContraseÃ±a</button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <!-- Modal -->
        <div id="confirmation-modal" class="modal">
            <div class="modal-content">
                <span class="close" id="closeModal">&times;</span>
                <p>¿Está seguro que desea cambiar la contraseña?</p>
                <div class="modal-buttons">
                    <button class="btn btn-info text-light" id="confirm-password-change">SÃ­, cambiar</button>
                    <button class="btn btn-primary text-light" id="cancel-password-change">No</button>
                </div>
            </div>
        </div>

        <!-- Vista cámara única -->
        <div id="single-camera-view" class="view-section" style="display: none;">
            <div class="single-camera-header d-flex justify-content-between align-items-center">
                <h2 id="single-camera-name"></h2>
                <a id="back-to-grid-btn" href="#" title="Volver a la cuadrÃ­cula">X</a>
            </div>
            <div class="single-view-main-area d-flex">
                <div id="single-camera-feed" class="feed-container flex-grow-1"></div>
                <div id="ptz-controls-sidebar" class="ptz-controls-sidebar">
                    <div class="ptz-group">
                        <h3>Movimiento</h3>
                        <div class="ptz-dpad">
                            <button data-ptz="up" title="Arriba">^</button> 
                            <button data-ptz="left" title="Izquierda">&lt;</button>
                            <button data-ptz="right" title="Derecha">&gt;</button> 
                            <button data-ptz="down" title="Abajo">v</button> 
                        </div>
                        <hr>
                        <div class="ptz-zoom">
                            <h3 class="text-center">Zoom</h3>
                            <button data-ptz="zoom-in" title="Zoom In">+</button>
                            <button data-ptz="zoom-out" title="Zoom Out">-</button>
                        </div>
                        <div class="ptz-group">
                            <h3>Acciones</h3>
                            <div class="ptz-actions">
                                <button class="capture-button-main" id="quick-capture-btn-single" title="Captura Rápida">Capturar</button>
                            </div>
                            <div id="notification-container" class="notification-container"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="js/dashboard.js"></script>
<script>
const role = '<?php echo $role; ?>'; 

document.addEventListener('DOMContentLoaded', () => {

    const menuBtn = document.getElementById('menuBtn');
    const sidebar = document.getElementById('sidebar');
    const closeSidebarBtn = document.getElementById('closeSidebar');
    const navLinks = document.querySelectorAll('#sidebar .nav-link');
    const views = document.querySelectorAll('.view-section');

    async function switchView(viewId, clickedLink = null) {
        if (!clickedLink) {
            clickedLink = document.querySelector(`#sidebar a[data-view="${viewId}"]`);
        }

        navLinks.forEach(l => l.classList.remove('active'));
        if (clickedLink) clickedLink.classList.add('active');

        views.forEach(section => {
            section.classList.remove('active-view');
            section.style.display = 'none';
        });

        const activeView = document.getElementById(`${viewId}-view`);
        if (activeView) {
            activeView.style.display = 'block';
            activeView.classList.add('active-view');
        }

        if (viewId === 'cameras') {
            if (typeof displayCamerasInGrid === 'function') await displayCamerasInGrid();
        } else if (viewId === 'captures') {
            if (typeof renderCaptures === 'function') await renderCaptures();
        } else if (viewId === 'camera-settings') {
            if (role === 'admin' && typeof displayCameraSettings === 'function') await displayCameraSettings();
        } else if (viewId === 'user-settings') {
            if (typeof renderUserList === 'function') await renderUserList();
        }
    }

    menuBtn.addEventListener('click', () => {
    sidebar.classList.add('active');
    document.getElementById('dashboard-wrapper').classList.add('menu-open');
});
closeSidebarBtn.addEventListener('click', () => {
    sidebar.classList.remove('active');
    document.getElementById('dashboard-wrapper').classList.remove('menu-open');
});
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const viewId = link.getAttribute('data-view');
            switchView(viewId, link);
        });
    });

    if (typeof setupEventListeners === 'function') setupEventListeners();

    const activeLink = document.querySelector('#sidebar .nav-link.active');
    if (activeLink) switchView(activeLink.getAttribute('data-view'), activeLink);

    // ==============================
    // FUNCIONES CRUD USUARIOS
    // ==============================

async function renderUserList() {
        const userList = document.getElementById('userList');
        const response = await fetch('api.php?action=getUsers');
        const data = await response.json();

        userList.innerHTML = '';

        data.users.forEach(user => {
            const div = document.createElement('div');
            div.classList.add('user-item');
            div.textContent = `${user.username} (${user.role})`;

            if (role === 'admin') {
                const editBtn = document.createElement('button');
                editBtn.textContent = 'Editar';
		editBtn.classList.add('btn', 'btn-primary', 'btn-sm', 'me-2', 'p-1', 'm-3'); 
                editBtn.onclick = () => editUser(user);

                const deleteBtn = document.createElement('button');
                deleteBtn.textContent = 'Eliminar';
		deleteBtn.classList.add('btn', 'btn-danger', 'btn-sm', 'me-2', 'p-1', 'm-3');
                deleteBtn.onclick = () => deleteUser(user.username);

                div.appendChild(editBtn);
                div.appendChild(deleteBtn);
            }

            userList.appendChild(div);
        });
    }

    // AGREGAR USUARIO
    const addUserForm = document.getElementById('addUser');
    if (addUserForm) {
        addUserForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const newRole = document.getElementById('role').value;

            const res = await fetch('api.php?action=addUser', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password, role: newRole })
            });

            const data = await res.json();
            alert(data.message);
            if (data.success) {
                addUserForm.reset();
                renderUserList();
            }
        });
    }

    // EDITAR USUARIO
    function editUser(user) {
        const newUsername = prompt('Nuevo nombre de usuario:', user.username);
        const newPassword = prompt('Nueva contraseña (dejar en blanco si no cambia):');
        const newRole = prompt('Nuevo rol:', user.role);

        if (!newUsername) return;

        fetch('api.php?action=editUser', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                oldUsername: user.username,
                username: newUsername,
                password: newPassword,
                role: newRole
            })
        })
        .then(res => res.json())
        .then(data => {
            alert(data.message);
            if (data.success) renderUserList();
        });
    }

    // ELIMINAR USUARIO
    function deleteUser(username) {
        if (!confirm(`¿Eliminar al usuario "${username}"?`)) return;

        fetch('api.php?action=deleteUser', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username })
        })
        .then(res => res.json())
        .then(data => {
            alert(data.message);
            if (data.success) renderUserList();
        });
    }

});
</script>
</body>
</html>
